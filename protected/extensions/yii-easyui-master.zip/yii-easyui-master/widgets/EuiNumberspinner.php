<?php

Yii::import('ext.yii-easyui.widgets.EuiSpinner');

class EuiNumberspinner extends EuiSpinner
{	
	
	public function getCssClass()
	{
		return 'easyui-numberspinner';
	}		
}
?>