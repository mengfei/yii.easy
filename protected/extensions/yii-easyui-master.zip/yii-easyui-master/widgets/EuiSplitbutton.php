<?php 

Yii::import('ext.yii-easyui.widgets.EuiMenubutton');

class EuiSplitbutton extends EuiMenubutton
{		
		
	public function getCssClass()
	{
		return 'easyui-splitbutton';
	}
		
}

?>